package view;

import java.util.Comparator;

import controllers.FieldAvgLinker;
import controllers.algorithms.BinarySearchInsertionSort;
import controllers.algorithms.SelectionSort;
import controllers.algorithms.ShakerSort;
import controllers.core.AbstractSwappingSortingAlgorithm;
import controllers.testing.*;
import controllers.testing.comparators.*;
import controllers.testing.generation.*;
import controllers.testing.generation.conversion.*;
import controllers.testing.results.swapping.Result;

public class Main {

	public static void main(String[] args) {
		Generator<MarkedValue<Integer>> generator = new MarkingGenerator<Integer>(new ReversedIntegerArrayGenerator());
		//Generator<MarkedValue<Integer>> generator = new MarkingGenerator<Integer>(new ReversedIntegerArrayGenerator());
		//Generator<MarkedValue<Integer>> generator = new MarkingGenerator<Integer>(new );

		AbstractSwappingSortingAlgorithm<MarkedValue<Integer>> alg = new ShakerSort<>(new MarkedValueComparator<Integer>(new IntegerComparator()));
		zawiszaVoid(alg, generator);

		graphVoid(generator, 20, 10000, 1000);
	}


	private static void graphVoid(Generator<MarkedValue<Integer>> generator, int repetitions, int maxSize, int stepSize) {
		Comparator<MarkedValue<Integer>> markedComparator = new MarkedValueComparator<Integer>(new IntegerComparator());

		AbstractSwappingSortingAlgorithm<MarkedValue<Integer>>[] algs = new AbstractSwappingSortingAlgorithm[] {
				new BinarySearchInsertionSort<MarkedValue<Integer>>(markedComparator),
				new SelectionSort<MarkedValue<Integer>>(markedComparator),
				new ShakerSort<MarkedValue<Integer>>(markedComparator),
				//	new BubbleSort<MarkedValue<Integer>>(markedComparator),
		};
		testAlgorithmsOptimal(generator, algs, repetitions, maxSize, stepSize);
	}


	private static void zawiszaVoid(AbstractSwappingSortingAlgorithm<MarkedValue<Integer>> algorithm, Generator<MarkedValue<Integer>> generator) {
		controllers.testing.results.swapping.Result result = Tester.runNTimes(algorithm, generator, 1000, 50);

		printStatistic("time [ms]", result.averageTimeInMilliseconds(), result.timeStandardDeviation());
		printStatistic("comparisons", result.averageComparisons(), result.comparisonsStandardDeviation());
		printStatistic("swaps", result.averageSwaps(), result.swapsStandardDeviation());

		System.out.println("always sorted: " + result.sorted());
		System.out.println("always stable: " + result.stable());
	}


	private static<T> void testAlgorithms(Generator<MarkedValue<T>> generator, AbstractSwappingSortingAlgorithm<MarkedValue<T>>[] algorithms, int repetitions, int maxSize, int stepSize) {
		FieldAvgLinker.DataSet[] swapsDatasets = new FieldAvgLinker.DataSet[algorithms.length];
		FieldAvgLinker.DataSet[] timeDatasets = new FieldAvgLinker.DataSet[algorithms.length];
		FieldAvgLinker.DataSet[] comparisonsDatasets = new FieldAvgLinker.DataSet[algorithms.length];

		for (int i = 0; i < algorithms.length; i++) {
			AbstractSwappingSortingAlgorithm<MarkedValue<T>> alg = algorithms[i];
			comparisonsDatasets[i] = FieldAvgLinker.Tools.dataSetFromAlgorithm(alg, generator, Result::averageComparisons, Result::comparisonsStandardDeviation, repetitions, maxSize, stepSize);
			swapsDatasets[i] = FieldAvgLinker.Tools.dataSetFromAlgorithm(alg, generator, Result::averageSwaps, Result::swapsStandardDeviation, repetitions, maxSize, stepSize);
			timeDatasets[i] = FieldAvgLinker.Tools.dataSetFromAlgorithm(alg, generator, Result::averageTimeInMilliseconds,Result::timeStandardDeviation, repetitions, maxSize, stepSize);
		}

		TrendPlotter.drawGraph(swapsDatasets, "zamianami");
		TrendPlotter.drawGraph(timeDatasets, "czasem");
		TrendPlotter.drawGraph(comparisonsDatasets, "porównaniami");
	}


	private static<T> void testAlgorithmsOptimal(Generator<MarkedValue<T>> generator, AbstractSwappingSortingAlgorithm<MarkedValue<T>>[] algorithms, int repetitions, int maxSize, int stepSize) {
		FieldAvgLinker.DataSet[] swapsDatasets = new FieldAvgLinker.DataSet[algorithms.length];
		FieldAvgLinker.DataSet[] timeDatasets = new FieldAvgLinker.DataSet[algorithms.length];
		FieldAvgLinker.DataSet[] comparisonsDatasets = new FieldAvgLinker.DataSet[algorithms.length];

		for (int i = 0; i < algorithms.length; i++) {
			AbstractSwappingSortingAlgorithm<MarkedValue<T>> alg = algorithms[i];
			FieldAvgLinker.DataSet[] algSets = FieldAvgLinker.Tools.dataSetsFromAlgorithm(alg, generator, repetitions, maxSize, stepSize,
					new FieldAvgLinker(Result::averageSwaps, Result::swapsStandardDeviation),
					new FieldAvgLinker(Result::averageComparisons, Result::comparisonsStandardDeviation),
					new FieldAvgLinker(Result::averageTimeInMilliseconds, Result::timeStandardDeviation));
			swapsDatasets[i] = algSets[0];
			comparisonsDatasets[i] = algSets[1];
			timeDatasets[i] = algSets[2];
		}

		TrendPlotter.drawGraph(swapsDatasets, "zamianami");
		TrendPlotter.drawGraph(timeDatasets, "czasem");
		TrendPlotter.drawGraph(comparisonsDatasets, "porównaniami");
	}


	private static void printStatistic(String label, double average, double stdDev) {
		System.out.println(label + ": " + double2String(average) + " +- " + double2String(stdDev));
	}


	private static String double2String(double value) {
		return String.format("%.12f", value);
	}
}
